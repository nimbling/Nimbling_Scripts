#target Illustrator #targetengine main
alert("There it is!");
pathToFile = app.activeDocument.path.fsName;
openPathCommand = new Folder(pathToFile);
openPathCommand.execute();
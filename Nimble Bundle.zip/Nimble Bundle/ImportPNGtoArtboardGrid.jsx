﻿#target Illustrator #targetengine main


// ASSUMES PNG'S OF 500x500 PX IN SAME FOLDER AS .AI File
// RENAMES ARTBOARDS TO NAME OF PNG FOUND
// Written by Robert Moggach & Qwertyfly
// Frankensteined together by Herman van Boeijen

app.pasteRemembersLayers = true;
var justclear = 1;

if ( app.documents.length > 0 ) {
	var saveclose = 1;
	var doc  = app.activeDocument;
	MeatAndPotatoes(doc);
}else{
	var saveclose = 1;
	files = File.openDialog("Select one or more files?", true);
	for(var f = 0; f < files.length; f++){
		var doc = app.open(files[f]);
		doc.activate();
		var doc = app.activeDocument;
		doc.views[0].screenMode = ScreenMode.FULLSCREEN;
		MeatAndPotatoes(doc);
	}
}
app.pasteRemembersLayers = false;

function MeatAndPotatoes(doc,f){
	importFolderAsLayers(getFolder(),doc);
	app.coordinateSystem = CoordinateSystem.ARTBOARDCOORDINATESYSTEM;
	if (justclear == 1){
		ClearAllArtboards(doc);
	} else {
		CenterEverythingToArtboards(doc);
	}
	if (saveclose==1) {
		doc.close( SaveOptions.SAVECHANGES );
		doc = null;
	}
}

function importFolderAsLayers(selectedFolder, doc) {
	// if a folder was selected continue with action, otherwise quit
	app.executeMenuCommand("selectall");
	app.executeMenuCommand("cut");
	app.coordinateSystem = CoordinateSystem.DOCUMENTCOORDINATESYSTEM;  
  
	if (selectedFolder) {
	  var firstImageLayer = true;
	  var newLayer;
	  var posX=0;
	  var posY=0;
	  var count=0;
	  var prettyname = "";
	  var rectside = 512;
	  var margin = 200;
		
	  // create document list from files in selected folder
	  var imageList = selectedFolder.getFiles();
  
	  for (var i = 0; i < imageList.length; i++) {
		if (imageList[i] instanceof File) {
		  var fileName = imageList[i].name.toLowerCase();
		  if( (fileName.indexOf(".png") == -1) ) {
			continue;
		  } else {
			var cutpoint = fileName.lastIndexOf(".");
			prettyname = (fileName.substring(0, cutpoint));
			// if(prettyname.indexOf("%")!=0){
			// 	alert(prettyname+" has weird characters");
			// 	var saveclose = 0;
			// 	}
			if( firstImageLayer ) {
			  newLayer = doc.layers[0];
			  firstImageLayer = false;
			  var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()];
			  activeAB.name = prettyname;
			} else {
			  newLayer = doc.layers.add();
			  box = newRect(posX, posY, rectside, rectside)
			  var AB = doc.artboards.add(box);
			  AB.name = prettyname;
			}
			// Name the Layer after the image file
			newLayer.name = prettyname;
  
			// Place the image
			newGroup = newLayer.groupItems.createFromFile( imageList[i] );
			newGroup.position = [ posX , posY ];
			var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()];
			box = newRect(posX, posY, rectside, rectside)
			activeAB.artboardRect = box;
		  }
		}
		
		posX += rectside + margin;
		if(posX >= (612*5)) {
		  posX = 0;
		  posY -= (rectside + margin);
		}
	  }
	  	  
	  if( firstImageLayer ) {
		// alert("The action has been cancelled.");
		// display error message if no supported documents were found in the designated folder
		alert("Sorry, but the designated folder does not contain any recognized image formats.\n\nPlease choose another folder.");
		doc.close();
		importFolderAsLayers(getFolder());
	  }
	} else {
	  // alert("The action has been cancelled.");
	  // display error message if no supported documents were found in the designated folder
	  alert("Rerun the script and choose a folder with images.");
	  //importFolderAsLayers(getFolder());
	}
}

function getFolder() {	// Frankensteined to just get the folder this file is in
	pathToFile = app.activeDocument.path;
	var selectedFolder = new Folder(pathToFile);
	return selectedFolder;
}

function newRect(x, y, width, height) {
    var l = 0;
    var t = 1;
    var r = 2;
    var b = 3;

    var rect = [];

    rect[l] = x;
    rect[t] = y;
    rect[r] = width + x;
    rect[b] = -(height - rect[t]);

    return rect;
}

function ScaleToArtboard(doc){
	var docw = doc.width;
	var doch = doc.height;

	var activeAB = doc.artboards[doc.artboards.getActiveArtboardIndex()]; // get active AB
	docLeft = activeAB.artboardRect[0];
	docTop = activeAB.artboardRect[1];
	// get selection bounds
	var sel = doc.selection[0];
	var selVB = sel.visibleBounds;
	var selVw = selVB[2]-selVB[0];
	var selVh = selVB[1]-selVB[3];
	var selGB = sel.geometricBounds;
	var selGw = selGB[2]-selGB[0];

	var selGh = selGB[1]-selGB[3];
	// get the difference between Visible & Geometric Bounds
	var deltaX = selVw-selGw;
	var deltaY = selVh-selGh;
	sel.width = docw-deltaX; // width is Geometric width, so we need to make it smaller...to accomodate the visible portion.
	sel.height = doch-deltaY;
	sel.top = docTop; // Top is actually Visible top
	sel.left = docLeft; // dito for Left
}

function ClearAllArtboards(doc){
	app.executeMenuCommand("selectall");
	app.executeMenuCommand("clear");
	app.executeMenuCommand("pasteInAllArtboard");	
}

function CenterEverythingToArtboards(doc){
	//Get total amount of groups
	var TotalArtboards = doc.artboards.length;
	//iterate all Artboards
	for (var i = 0 ; i < TotalArtboards ; i++){
		var CurrentArtboard = doc.artboards[i];
		doc.artboards.setActiveArtboardIndex(i);
		//Select everything on artboard
		doc.selectObjectsOnActiveArtboard(i);
		app.executeMenuCommand("clear");
		app.executeMenuCommand("pasteInAllArtboard");
		// ScaleToArtboard(doc);
		}
}
﻿#target "illustrator"

app.executeMenuCommand("EditOriginal Menu Item");
﻿// Выделение всех объектов c оверпринтом.

#target "illustrator"
#targetengine "main"

#include "ProgressBar.incjsx"
#include "Select.incjsx"



alert("PRESS ENTER");
// app.redraw();

Select('pathItems', function(pi){
    return pi.fillOverprint;        
});

// Select();

var doc = app.activeDocument;                   //current document
var sel = doc.selection;                       //current slection
var sl = sel.length; 

for (var i = 0; i < sl; i++) {
    sel[i].fillOverprint = false
  }



aiDocument = app.activeDocument; aiDocument.close( SaveOptions.SAVECHANGES ); aiDocument = null;
#target Illustrator
#targetengine main
if ( app.documents.length > 0 ) {
    var curDoc = app.activeDocument;
}else{
    Window.alert("You must open at least one document.");
}
#include "color-conversion-algorithms.jsx"
increment = 0.025;

var sel = curDoc.selection; // get selection

for (var i = 0; i < sel.length; i++) {
    if (sel[i].filled == true){
        sel[i].fillColor=hueDown(sel[i].fillColor);
    }
    if (sel[i].stroked == true){
        sel[i].strokeColor=hueDown(sel[i].strokeColor);
    }
}

function hueDown(fillColor){
    r = fillColor.red;
    g = fillColor.green;
    b = fillColor.blue;
    inihsv = rgbToHsv(r,g,b).toString();
    interhsv = inihsv.split(",");
    newh = parseFloat(interhsv[0]) - increment;
    if (newh < 0) {
        newh = newh + 1;
    }
    newrgb = hsvToRgb(newh,interhsv[1],interhsv[2]).toString();
    freshrgb = newrgb.split(",");
    var freshRGBColor = new RGBColor();
    freshRGBColor.red = freshrgb[0];
    freshRGBColor.green = freshrgb[1];
    freshRGBColor.blue = freshrgb[2];
    return freshRGBColor;    
}


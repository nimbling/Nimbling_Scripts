#target Illustrator

if ( app.documents.length > 0 ) {
    var curDoc = app.activeDocument;
}else{
    Window.alert("You must open at least one document.");
}
var sel = curDoc.selection;
var amountofselectedobjects = sel.length;
// alert(amountofselectedobjects);

if (amountofselectedobjects == 1) {
    app.doScript("Close Path", "Helpers");
} else if (amountofselectedobjects == 2) {
    app.doScript("Join Paths", "Helpers");
}
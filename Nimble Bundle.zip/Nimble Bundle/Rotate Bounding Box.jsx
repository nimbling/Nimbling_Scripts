#target illustrator

function test(){

    var doc = app.activeDocument;

    var sel = doc.selection[0];
    // alert(sel.tags.length);
    if(sel.tags.length > 0 && sel.tags[0].name == "BBAccumRotation"){
    var degrees = toDegrees(sel.tags[0].value); 
      alert(degrees); //in degrees
    }

    sel.rotate(-degrees);

};

test();


// #target Illustrator
// #targetengine main

// if ( app.documents.length > 0) {
//     var selection = app.activeDocument.selection;
//     if (selection.length > 0) {
//         var voorzet = 0;
//         var RotateBB = prompt("Rotate BB by:", voorzet);
//         for (var i = 0; i < selection.length; i++) {
//             selection[i].rotate(RotateBB);
//             app.executeMenuCommand ('AI Reset Bounding Box');
//             selection[i].rotate(-RotateBB);
//         }
//     } else {
//       alert("no object(s) selected")
//     }
// }


function toDegrees (angle) {
    return angle * (180 / Math.PI);
  }
  
  function toRadians (angle) {
    return angle * (Math.PI / 180);
  }
#target illustrator
app.doScript("Grow Points", "Grow and Shrink Points");
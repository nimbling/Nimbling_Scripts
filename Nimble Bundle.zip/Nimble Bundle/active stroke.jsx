#target illustrator
app.doScript("FocusOnStroke", "Helpers");
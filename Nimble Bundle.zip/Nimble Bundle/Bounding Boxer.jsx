#target illustrator

function test(){

    var doc = app.activeDocument;
    var originalselection = doc.selection;
    if (originalselection!=2){
      exit();
    }
    var sel = doc.selection[0];
    var sel2 = doc.selection[1];
    
    doc.selection = sel;
    app.doScript("Expand Shape", "Helpers");
    doc.selection = originalselection;

    // alert(sel.tags.length);
    if(sel.tags.length > 0 && sel.tags[0].name == "BBAccumRotation"){     
        var degrees = toDegrees(sel.tags[0].value);
        var BBAccumRotationTAG = sel2.tags.add();
        BBAccumRotationTAG.name = "BBAccumRotation";
        BBAccumRotationTAG.value = toRadians(degrees);
    }
    sel.remove();
};

test();


// #target Illustrator
// #targetengine main

// if ( app.documents.length > 0) {
//     var selection = app.activeDocument.selection;
//     if (selection.length > 0) {
//         var voorzet = 0;
//         var RotateBB = prompt("Rotate BB by:", voorzet);
//         for (var i = 0; i < selection.length; i++) {
//             selection[i].rotate(RotateBB);
//             app.executeMenuCommand ('AI Reset Bounding Box');
//             selection[i].rotate(-RotateBB);
//         }
//     } else {
//       alert("no object(s) selected")
//     }
// }


function toDegrees (angle) {
    return angle * (180 / Math.PI);
  }
  
  function toRadians (angle) {
    return angle * (Math.PI / 180);
  }
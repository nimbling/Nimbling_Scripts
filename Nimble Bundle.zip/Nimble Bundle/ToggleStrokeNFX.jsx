#target Illustrator
#targetengine main

//INIT, Is there a document open?
if ( app.documents.length > 0 ) {
    var curDoc = app.activeDocument;
}else{
    Window.alert("You must open at least one document.");
}

var scalestate = app.preferences.getBooleanPreference('scaleLineWeight');
if(scalestate==true){
    app.preferences.setBooleanPreference('scaleLineWeight',false);
    var f = File(File($.fileName).parent+"/alertoff.app");
    f.execute();
} else {
    app.preferences.setBooleanPreference('scaleLineWeight',true);
    var f = File(File($.fileName).parent+"/alerton.app");
    f.execute();
}


#target Illustrator
#targetengine main

//  script.name = Unclip.jsx;
//  script.parent = Herman van Boeijen, www.nimbling.com // 28-01-2019;
//  Big thanks to CarlosCanto and MuppetMark on the Adobe Illustrator Scripting Forums
// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


//INIT, Is there a document open?
#include "Send Behind.jsx"

if ( app.documents.length > 0 ) {
    var curDoc = app.activeDocument;
}else{
    Window.alert("You must open at least one document.");
}

var sel = curDoc.selection; // get selection
var origsel = curDoc.selection;
var amountofselectedobjects = sel.length;
var clipobject = sel[amountofselectedobjects -1]; // BOTTOM OBJECT
alert(clipobject.pageItems[0]);
var clipcolors = [];

Main(curDoc, sel, amountofselectedobjects, clipobject);

function Main(curDoc, sel, amountofselectedobjects, clipobject){
    if (amountofselectedobjects){
        if(curDoc.activeLayer.locked || !curDoc.activeLayer.visible){
            alert("Please select objects on an unlocked and visible layer,\nthen run this script again.");
        }else{
            // doc.selection = clipobject.pageItems[0].pathItems[0];
            // app.executeMenuCommand('copy');
            // app.executeMenuCommand('Live Pathfinder Crop');
            // app.executeMenuCommand('expandStyle');
            // app.executeMenuCommand('ungroup');
            // app.executeMenuCommand('pasteBack');
            // app.executeMenuCommand('releaseMask');
            // sel = curDoc.selection;
            // amountofselectedobjects = sel.length;
            // app.executeMenuCommand('deselectall');
            // for (i = 1; i < amountofselectedobjects ; i++) {
            //     killobject = sel[i];
            //     killobject.remove();
            // }
        }
    }
}
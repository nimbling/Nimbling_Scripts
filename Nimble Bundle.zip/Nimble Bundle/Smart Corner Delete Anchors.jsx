#target illustrator
app.doScript("Smart Anchors Delete", "Helpers");
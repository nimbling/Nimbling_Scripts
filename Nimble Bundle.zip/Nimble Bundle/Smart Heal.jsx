#target illustrator
// app.doScript("Join Paths", "Helpers");
// app.executeMenuCommand ('Smart Heal');
app.doScript("Smart Heal", "Helpers");
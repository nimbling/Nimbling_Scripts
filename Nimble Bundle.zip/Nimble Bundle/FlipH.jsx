﻿#target Illustrator
app.doScript("FlipH", "Helpers")

// MY OWN FANCY ONE
// if ( app.documents.length > 0 ) {
// 	mySelection = activeDocument.selection;
// 	if (mySelection.length>0){
// 	    var doc = app.activeDocument;                   //current document
// 	    var sel  = doc.selection;                 //current slection
// 	    var sl   = sel.length;                            //number of selected objects

// 		var m  = app.getScaleMatrix(-100,100);          //H flip matrix - feel free to change to (100,-100) for vertical flip, etc.
// 			newGroup = app.activeDocument.activeLayer.groupItems.add();
// 			var backitem = sel[sl-1];
// 			newGroup.move (backitem , ElementPlacement.PLACEAFTER);
// 	    for(var i = 0 ; i < sl; i++) sel[i].move( newGroup , ElementPlacement.PLACEATBEGINNING); //Group these fuckers!
// 			newGroup.transform(m); //apply the flip matrix to the group
// 			for(var i = 0 ; i < sl; i++) sel[i].move( newGroup , ElementPlacement.PLACEBEFORE); //Release them from their groupness :)
// 	    app.redraw();
// 	}else{
// 	    alert("Nothing selected!")
// 	}
// }



// FANCY MATRIX STUFF:
// function applyTM(tg, a, b, c, d) {
// 	var tm = new Matrix();  
// 	tm.mValueA = a;  
// 	tm.mValueB = b;  
// 	tm.mValueC = c;  
// 	tm.mValueD = d;  
// 	tm.mValueTX = 0;  
// 	tm.mValueTY = 0;  
// 	tg.transform(tm,true,true,true,true,1);  
// 	app.redraw();  
// 	}
  
//   applyTM (app.activeDocument.selection[0],-1,0,0,1);
  
// //   applyTM (app.activeDocument.selection[0],1,0,0,-1);
﻿#target Illustrator
#targetengine main

//  script.name = Swap Object Colors.jsx;
//  script.required = Exactly two paths selected;
//  script.parent = Herman van Boeijen, www.nimbling.com // 07/12/13;
//  Big thanks to CarlosCanto and MuppetMark on the Adobe Illustrator Scripting Forums


    if ( app.documents.length > 0 ) {
        var curDoc = app.activeDocument;
    }else{
        Window.alert("You must open at least one document.");
    }

    var sel = curDoc.selection; // get selection
    var firstobject = sel[0];
    var secondobject = sel[1];
    var firstcolors = [];
    var secondcolors = [];
    var container = curDoc.activeLayer;

function Main(sel, firstobject, secondobject, firstcolors, secondcolors, container){
    //Only if there are objects selected
    if (sel.length == 2) {
        if(container.locked || !container.visible){
            alert("Please select exactly TWO objects on an unlocked and visible layer,\nthen run this script again.");
        }else{
            SwapObjCol(sel, curDoc, firstcolors, secondcolors);
        }
    } else {
        alert("Please select exactly TWO objects on an unlocked and visible layer,\nthen run this script again.");
        return;
    }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
function SwapObjCol(sel, curDoc, firstcolors, secondcolors){
        if (sel[0].typename === "CompoundPathItem") {
            firstobject = sel[0].pathItems[0];
        }
        if (sel[1].typename === "CompoundPathItem") {
            secondobject = sel[1].pathItems[0];
        }

        CopyAppearance(firstobject, firstcolors);
        CopyAppearance(secondobject, secondcolors);           
        PasteAppearance(firstobject, secondcolors);
        PasteAppearance(secondobject, firstcolors);
}

function CopyAppearance() {
            if(arguments[0].filled)  {
                arguments[1].fillColor = arguments[0].fillColor;
            }
            if(arguments[0].stroked) {
                arguments[1].stroked = arguments[0].stroked;
                arguments[1].strokeWidth = arguments[0].strokeWidth;
                arguments[1].strokeColor = arguments[0].strokeColor;
            }
}

function PasteAppearance() {
            if(arguments[1].fillColor)    {
                arguments[0].fillColor = arguments[1].fillColor;
            }
            if(arguments[1].stroked)      {
                arguments[0].stroked = arguments[1].stroked;
                arguments[0].strokeWidth = arguments[1].strokeWidth;
                arguments[0].strokeColor = arguments[1].strokeColor;
            } else {
                arguments[0].stroked = 0;
            }
}

Main(sel, firstobject, secondobject, firstcolors, secondcolors, container);
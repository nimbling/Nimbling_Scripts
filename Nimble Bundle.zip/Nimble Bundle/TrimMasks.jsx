#target Illustrator
$.localize = true; // Enabling automatic localization
// app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;

if ( app.documents.length > 0 ) {
  var curDoc = app.activeDocument;
}else{
  Window.alert("You must open at least one document.");
}
var selection = curDoc.selection; // get selection

// Global variables
var AI_VER = parseInt(app.version),
    LANG_ERR_DOC = { en: 'Error\nOpen a document and try again.',
                     ru: 'Ошибка\nОткройте документ и запустите скрипт.'},
    LANG_ERR_VER = { en: 'Error\nSorry, script only works in Illustrator CS6 and above.',
                     ru: 'Ошибка\nСкрипт работает в Illustrator CS6 и выше.'},
    SAVE_FILLED_CLIPMASK = true, // true — save the filled mask path when trimming, false - not save
    itemAttr = { mOpacity: 100, mBlending: BlendModes.NORMAL };

function main() {
  if (app.documents.length == 0) {
    alert(LANG_ERR_DOC);
    return;
  }

  if (AI_VER < 16) {
    alert(LANG_ERR_VER);
    return;
  }

  var doc = app.activeDocument;
      // userScreen = doc.views[0].screenMode;
 
  var groups = getGroups(selection);
  try {
    processing(groups);
  } catch (e) {
    // showError(e);
  }

  resetSelection();
  // doc.views[0].screenMode = userScreen;
  // app.userInteractionLevel = UserInteractionLevel.DISPLAYALERTS;
}

function processing(items) {
  var currItem;
  for (var i = 0; i < items.length; i++) {
    resetSelection();
    currItem = items[i];
    if (currItem.typename === 'GroupItem' && currItem.clipped) {
      trim(currItem);
    }
    if (currItem.typename === 'GroupItem' && !currItem.clipped) {
      if (currItem.pageItems.length == 1 && currItem.pageItems[0].typename === 'GroupItem') {
        var singleItem = currItem.pageItems[0];
        singleItem.moveBefore(currItem);
        trim(singleItem);
      } else {
        processing(currItem.pageItems);
      }
    }
  }
}

function trim(item) {
  // Save opacity & blendingMode properties
  if (item.opacity < 100) { itemAttr.mOpacity = item.opacity; }
  if (item.blendingMode != BlendModes.NORMAL) { itemAttr.mBlending = item.blendingMode; }
  
  // If <clip group> contains live text
  outlineText(item);
  
  // Trick for Compound path created from groups of paths
  item.selected = true;
  compoundPathsNormalize(selection);
  
  if (SAVE_FILLED_CLIPMASK) { 
    duplicateFilledMask(item, itemAttr.mOpacity, itemAttr.mBlending);
  }
  
  item.selected = true;
  if (SAVE_FILLED_CLIPMASK) {
    // Because the duplicate mask is select behind
    selection = selection[0];
  }
  app.doScript("Crop", "Helpers");

  if (selection.length > 0) {
    // Restore opacity to child path
    if (itemAttr.mOpacity < 100) { selection[0].opacity = itemAttr.mOpacity; }
    // Restore blendingMode to child path
    if (itemAttr.mBlending != BlendModes.NORMAL) { selection[0].blendingMode = itemAttr.mBlending; }
  }

  itemAttr = { mOpacity: 100, mBlending: BlendModes.NORMAL };
}

// Get only groups from selection or document
function getGroups(items) {
  var childsArr = [],
      currItem;
  for (var i = 0; i < items.length; i++) {
    currItem = items[i];
    if (currItem.typename === 'GroupItem') { 
      childsArr.push(currItem);
    }
  }
  return childsArr;
}

function outlineText(group) {
  try {
    for (var i = 0; i < group.pageItems.length; i++) {
      var currItem = group.pageItems[i],
          itemType = currItem.typename;
      if (itemType === 'TextFrame') { 
        var textColor = currItem.textRange.fillColor;
        currItem.selected = true;
        app.executeMenuCommand('outline');
        for (var j = 0; j < selection.length; j++) {
          if (selection[j].typename  === 'PathItem') selection[j].fillColor = textColor;
          if (selection[j].typename  === 'CompoundPathItem') {
            // Trick for Compound path created from groups of paths
            if (selection[j].pathItems.length == 0) {
              var tempPath = selection[j].pathItems.add();
            }
            selection[j].pathItems[0].fillColor = textColor;
            tempPath.remove();
          }
        }
        resetSelection();
      }
      if (itemType === 'GroupItem') {
        outlineText(currItem);
      }
    }
  } catch (e) {
    // showError(e);
  }
}

function ungroup(items) {
  for (var i = 0; i < items.length; i++) {
    if (items[i].typename === 'GroupItem') {
      var j = items[i].pageItems.length;
      while (j--) {
        items[i].pageItems[0].locked = items[i].pageItems[0].hidden = false;
        items[i].pageItems[0].moveBefore(items[i]);
      }
      items[i].remove();
    }
  }
}

// Trick for Compound path created from groups of paths
function compoundPathFix(item) {
  selection = [item];
  app.executeMenuCommand('noCompoundPath');
  ungroup(selection);
  app.executeMenuCommand('compoundPath');
  resetSelection();
}

// From compoundFix.jsx by Alexander Ladygin https://github.com/alexander-ladygin
function compoundPathsNormalize(items) {
  var i = items.length;
  while (i--) {
    if (items[i].typename === 'GroupItem') {
      compoundPathsNormalize(items[i].pageItems);
    } else if (items[i].typename === 'CompoundPathItem') {
      compoundPathFix(items[i]);
    }
  }
}

function duplicateFilledMask(group, opacity, blending) {
  try {
    for (var i = 0; i < group.pageItems.length; i++) {
      var currItem = group.pageItems[i],
          itemType = currItem.typename,
          zeroPath = (itemType === 'CompoundPathItem') ? currItem.pathItems[0] : currItem;

      if ((itemType === 'PathItem' || itemType === 'CompoundPathItem') && zeroPath.clipping && zeroPath.filled) {
        var maskClone = currItem.duplicate(group, ElementPlacement.PLACEAFTER);
            // Restore opacity to child path
            if (opacity < 100) { maskClone.opacity = opacity; }
            // Restore blendingMode to child path
            if (blending != BlendModes.NORMAL) { maskClone.blendingMode = blending; }
      }
    }
    // app.redraw();
  } catch (e) {
    // showError(e);
  }
}

function resetSelection() {
  selection = null;
  // app.redraw();
}

function showError(err) {
  alert(err + ': on line ' + err.line, 'Script Error', true);
}

try {
  main();
} catch (e) {
  // showError(e);
}
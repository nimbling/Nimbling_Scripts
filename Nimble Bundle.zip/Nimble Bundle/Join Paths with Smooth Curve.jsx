function handlePos(anc, hand) {
    var angle = get2PointsAngle(anc, hand) - 180;
    var dist = get2PointsDist(anc, hand);
    var a = anc[0] + (dist * Math.cos(angle * (Math.PI / 180)));
    var b = anc[1] + (dist * Math.sin(angle * (Math.PI / 180)));
    return [a, b];
}

function get2PointsDist(a, b) {
    return Math.sqrt(Math.pow(b[0] - a[0], 2) + Math.pow(b[1] - a[1], 2));
}

function get2PointsAngle(a, b) {
    return (Math.atan2(b[1] - a[1], b[0] - a[0]) * 180) / Math.PI;
}

function getBothEnd(sels) {
    var arr = [];
    for (var i = 0; i < sels.length; i += 1) {
        var sel = sels[i];
        if (sels[i].typename === "PathItem" && sels[i].closed === false) {
            var ps = sels[i].pathPoints;
            var obj1 = {};
            obj1.anchor = ps[0].anchor;
            obj1.leftDirection = ps[0].leftDirection;
            obj1.rightDirection = ps[0].rightDirection;
            if (obj1.anchor[0] === obj1.leftDirection[0] && obj1.anchor[1] === obj1.leftDirection[1]) {
                obj1.leftDirection = handlePos(obj1.anchor, obj1.rightDirection);
            }
            arr.push(obj1);
            var obj2 = {};
            obj2.anchor = ps[ps.length - 1].anchor;
            obj2.leftDirection = ps[ps.length - 1].leftDirection;
            obj2.rightDirection = ps[ps.length - 1].rightDirection;
            if (obj2.anchor[0] === obj2.rightDirection[0] && obj2.anchor[1] === obj2.rightDirection[1]) {
                obj2.rightDirection = handlePos(obj2.anchor, obj2.leftDirection);
            }
            arr.push(obj2);
        }
    }
    return arr;
}
if (documents.length > 0) {
    var doc = app.activeDocument;
    var sels = doc.selection;
    if (sels.length > 0 && sels.typename !== "TextRange") {
        var points = getBothEnd(sels);
        if (points.length > 0) {
            app.executeMenuCommand("join");
            app.redraw();
            var newSels = doc.selection;
            if (sels.length >= newSels.length) {
                var newSel = newSels[0];
                for (var i = 0; i < newSel.pathPoints.length; i += 1) {
                    var pp = newSel.pathPoints[i];
                    var ppA = pp.anchor;
                    var ppL = pp.leftDirection;
                    var ppR = pp.rightDirection;
                    for (var j = 0; j < points.length; j += 1) {
                        var xp = points[j];
                        var xpA = xp.anchor;
                        var xpL = xp.leftDirection;
                        var xpR = xp.rightDirection;
                        if (ppA[0] === xpA[0] && ppA[1] === xpA[1]) {
                            if (ppL[0] === xpL[0] && ppL[1] === xpL[1]) {
                                pp.rightDirection = [xpR[0], xpR[1]];
                            } else {
                                if (ppL[0] === xpR[0] && ppL[1] === xpR[1]) {
                                    pp.rightDirection = [xpL[0], xpL[1]];
                                }
                            }
                            if (ppR[0] === xpL[0] && ppR[1] === xpL[1]) {
                                pp.leftDirection = [xpR[0], xpR[1]];
                            } else {
                                if (ppR[0] === xpR[0] && ppR[1] === xpR[1]) {
                                    pp.leftDirection = [xpL[0], xpL[1]];
                                }
                            }
                            pp.pointType = PointType.SMOOTH;
                        }
                    }
                }
                newSel.selected = false;
                newSel.selected = true;
            }
        }
    }
}
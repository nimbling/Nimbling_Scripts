#target illustrator
app.doScript("Shrink Points", "Grow and Shrink Points");
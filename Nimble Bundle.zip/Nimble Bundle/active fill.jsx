#target illustrator
app.doScript("FocusOnFill", "Helpers");